library(readxl)
#IMPORTATION ET NETTOYAGE
data <- read.csv("C:/Users/Lenovo/Downloads/Projet2_Fraude_MobileMoney.csv")
head(data)
#VERIFICATION DES VALEURS MANQAUNTES
colSums(is.na(data))
# Remplacer NA si besoin
data$Montant_transfere_FCFA[is.na(data$Montant_transfere_FCFA)] <- 0

# Transformer en facteur
data$Est_frauduleuse <- as.factor(data$Est_frauduleuse)
data$Operateur <- as.factor(data$Operateur)
data$Type_transaction <- as.factor(data$Type_transaction)
#DISTRIBUTION DES MONTANTS PAR OPERATEURS
boxplot(Montant_transfere_FCFA ~ Operateur, data=data,
        main="Montant par opérateur",
        col="lightblue")
#REPARTITION PAR TYPE DE TRANSACTION 
barplot(table(data$Type_transaction),
        col="orange",
        main="Types de transaction")
#ANALYSE PAR H
hist(data$Heure_transaction,
     col="green",
     main="Heures des transactions",
     xlab="Heure")
#DETECTION DES COMPORTEMENTS SUSPECT
summary(data$Montant_transfere_FCFA)
#TRANSACTION DE NUIT
subset(data, Heure_transaction >= 0 & Heure_transaction <= 4)
#ARBRES DE DECISSION 
install.packages("rpart")
library(rpart)

model_tree <- rpart(Est_frauduleuse ~ Montant_transfere_FCFA +
                      Heure_transaction + Type_transaction + Operateur,
                    data=data, method="class")

print(model_tree)
#REGRESSION LOGIQUE
model_logit <- glm(Est_frauduleuse ~ Montant_transfere_FCFA +
                     Heure_transaction + Type_transaction + Operateur,
                   data=data, family=binomial)

summary(model_logit)
#EVALUATION 
model_data <- model.frame(model_logit)

pred <- predict(model_logit, type = "response")

pred_class <- ifelse(pred > 0.5, 1, 0)

table(Prediction = pred_class, Reel = model_data$Est_frauduleuse)
#PRECISSION
mean(pred_class == data$Est_frauduleuse)
