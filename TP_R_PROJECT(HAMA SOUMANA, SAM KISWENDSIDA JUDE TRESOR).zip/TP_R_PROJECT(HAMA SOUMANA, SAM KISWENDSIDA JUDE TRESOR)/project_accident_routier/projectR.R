library(readr)
library(dplyr)
getwd()
data<-read_csv("C:/Users/Lenovo/Downloads/Projet3_Accidents_Routiers.csv")
head(data)
#verification des valeure manquante
colSums(is.na(data))

#traitement des valeurs manquantes
data$Nombre_blesses[is.na(data$Nombre_blesses)]<-0
data$Nombre_morts[is.na(data$Nombre_morts)]<-0
#distribution des accidents par route
table(data$Type_de_route)
#distribution des accidents par region
table(data$Region)

#Visualiser les causes principales d’accident (ggplot2, plotly).
library(ggplot2)
library(plotly)
ggplot(data,aes(x=Cause_principale))+
        geom_bar(fill= "red")+
        theme_minimal()+
        labs(title="causes principales d’accident",
             x="cause",y="nombre")

p <- ggplot(data,aes(x=Cause_principale))+
    geom_bar(fill="orange")
    ggplotly(p)
names(data)

#Identifier les zones les plus à risque.
data%>%
  group_by(Region)%>%
  summarise(
    total_morts=sum(Nombre_morts),
    total_blesses=sum(Nombre_blesses)
  )%>%
  arrange(desc(total_morts))

#Effectuer un clustering des routes selon la gravité (nombre de morts/blessés).
clust_data <- data%>%
  select(Nombre_morts,Nombre_blesses)
clust_data_scaled <- scale(clust_data)
#application K-mens
 set.seed(123)
 kmeans_result <- kmeans(clust_data_scaled, centers =3)
 data$cluster <- kmeans_result$cluster
 
 #visualisation
 library(ggplot2)
 ggplot(data,aes(x=Nombre_blesses,y=Nombre_morts,color=as.factor(cluster)))+
   geom_point()+
   theme_minimal()+
   labs(color="cluster")
 
 #Regression lineaire
 model<-lm(Nombre_morts~Cause_principale + Type_de_route + Nombre_vehicules_implique,data = data)
 summary(model)