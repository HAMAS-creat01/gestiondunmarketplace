import java.sql.*;
import java.util.Scanner;

public class ServiceMarketplace {

    public void ajouterUtilisateur(String nom, boolean estVendeur) {
        try (Connection conn = ConnexionDB.getConnection()) {
            String sql = "INSERT INTO utilisateurs(nom, est_vendeur) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nom);
            stmt.setBoolean(2, estVendeur);
            stmt.executeUpdate();
            System.out.println("Utilisateur ajouté avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void ajouterProduit(String nom, double prix, int vendeurId) {
        try (Connection conn = ConnexionDB.getConnection()) {
            String sql = "INSERT INTO produits(nom, prix, vendeur_id) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, nom);
            stmt.setDouble(2, prix);
            stmt.setInt(3, vendeurId);
            stmt.executeUpdate();
            System.out.println("Produit ajouté avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void afficherProduits() {
        try (Connection conn = ConnexionDB.getConnection()) {
            String sql = "SELECT * FROM produits";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            System.out.println("--- Liste des produits ---");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " - " + rs.getString("nom") + " - " + rs.getDouble("prix") + "€");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void acheterProduit(int idProduit) {
        try (Connection conn = ConnexionDB.getConnection()) {
            String sql = "DELETE FROM produits WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idProduit);
            int lignes = stmt.executeUpdate();

            if (lignes > 0) {
                System.out.println("Produit acheté avec succès !");
            } else {
                System.out.println("Produit introuvable.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
