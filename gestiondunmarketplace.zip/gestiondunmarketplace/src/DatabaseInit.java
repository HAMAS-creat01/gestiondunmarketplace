import java.sql.Connection;
import java.sql.Statement;

public class DatabaseInit {
    public static void initialiser() {
        try (Connection conn = ConnexionDB.getConnection();
             Statement stmt = conn.createStatement()) {

            String sqlUtilisateurs = """
                CREATE TABLE IF NOT EXISTS utilisateurs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nom TEXT NOT NULL,
                    est_vendeur BOOLEAN NOT NULL
                );
            """;

            String sqlProduits = """
                CREATE TABLE IF NOT EXISTS produits (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nom TEXT NOT NULL,
                    prix REAL NOT NULL,
                    vendeur_id INTEGER,
                    FOREIGN KEY(vendeur_id) REFERENCES utilisateurs(id)
                );
            """;

            stmt.execute(sqlUtilisateurs);
            stmt.execute(sqlProduits);

            System.out.println("Base de données initialisée.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
