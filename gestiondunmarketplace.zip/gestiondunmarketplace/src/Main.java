import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ServiceMarketplace service = new ServiceMarketplace();


        DatabaseInit.initialiser();

        boolean actif = true;
        while (actif) {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1. Ajouter un utilisateur");
            System.out.println("2. Ajouter un produit");
            System.out.println("3. Afficher les produits");
            System.out.println("4. Acheter un produit");
            System.out.println("5. Quitter");
            System.out.print("Choix : ");
            int choix = scanner.nextInt();
            scanner.nextLine();

            switch (choix) {
                case 1 -> {
                    System.out.print("Nom : ");
                    String nom = scanner.nextLine();
                    System.out.print("Est-ce un vendeur ? (true/false) : ");
                    boolean estVendeur = scanner.nextBoolean();
                    scanner.nextLine();
                    service.ajouterUtilisateur(nom, estVendeur);
                }
                case 2 -> {
                    System.out.print("Nom du produit : ");
                    String nom = scanner.nextLine();
                    System.out.print("Prix : ");
                    double prix = scanner.nextDouble();
                    System.out.print("ID du vendeur : ");
                    int vendeurId = scanner.nextInt();
                    scanner.nextLine();
                    service.ajouterProduit(nom, prix, vendeurId);
                }
                case 3 -> service.afficherProduits();
                case 4 -> {
                    System.out.print("ID du produit à acheter : ");
                    int idProduit = scanner.nextInt();
                    scanner.nextLine();
                    service.acheterProduit(idProduit);
                }
                case 5 -> {
                    actif = false;
                    System.out.println("Fermeture...");
                }
                default -> System.out.println("Choix invalide.");
            }
        }

        scanner.close();
    }
}
