public class Utilisateur {
    private int id;
    private String nom;
    private boolean estVendeur;

    public Utilisateur(int id, String nom, boolean estVendeur) {
        this.id = id;
        this.nom = nom;
        this.estVendeur = estVendeur;
    }

    public int getId() { return id; }
    public String getNom() { return nom; }
    public boolean estVendeur() { return estVendeur; }

    @Override
    public String toString() {
        return nom + (estVendeur ? " (Vendeur)" : " (Acheteur)");
    }
}
