public class Produit {
    private int id;
    private String nom;
    private double prix;
    private int vendeurId;

    public Produit(int id, String nom, double prix, int vendeurId) {
        this.id = id;
        this.nom = nom;
        this.prix = prix;
        this.vendeurId = vendeurId;
    }

    public int getId() { return id; }
    public String getNom() { return nom; }
    public double getPrix() { return prix; }
    public int getVendeurId() { return vendeurId; }

    @Override
    public String toString() {
        return id + " - " + nom + " (" + prix + "€)";
    }
}
